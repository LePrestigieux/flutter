package com.leprestigieux.flutter_app2;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
